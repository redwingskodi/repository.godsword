﻿import xbmcaddon

MainBase = 'https://gitlab.com/redwingskodi/church/raw/master/home.txt'
addon = xbmcaddon.Addon('plugin.video.GodsWord')
